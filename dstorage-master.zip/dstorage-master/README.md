## ``` Decentralized File Storage. ```


## 🔧 Project Diagram:
![Project Diagram](https://i.gyazo.com/2738ea6743a40036756b1b5714ab9fa8.png)